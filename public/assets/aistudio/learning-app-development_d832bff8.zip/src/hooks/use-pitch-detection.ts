"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { NOTE_BY_ID } from "@/lib/music-data";

const NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];

type MicrophoneResources = {
  stream: MediaStream;
  context: AudioContext;
  source: MediaStreamAudioSourceNode;
  analyser: AnalyserNode;
  timer: number;
};

function estimateFrequency(buffer: Float32Array, sampleRate: number): number | null {
  let energy = 0;
  for (let i = 0; i < buffer.length; i++) energy += buffer[i] * buffer[i];
  if (Math.sqrt(energy / buffer.length) < 0.014) return null;

  const minLag = Math.floor(sampleRate / 1100);
  const maxLag = Math.min(Math.floor(sampleRate / 230), Math.floor(buffer.length / 2));
  const correlations: number[] = [];
  let strongest = 0;

  for (let lag = minLag; lag <= maxLag; lag++) {
    let sum = 0;
    let left = 0;
    let right = 0;
    for (let i = 0; i < buffer.length - lag; i += 2) {
      const a = buffer[i];
      const b = buffer[i + lag];
      sum += a * b;
      left += a * a;
      right += b * b;
    }
    const correlation = sum / Math.sqrt(left * right + 0.000001);
    correlations.push(correlation);
    strongest = Math.max(strongest, correlation);
  }

  if (strongest < 0.7) return null;
  for (let i = 1; i < correlations.length - 1; i++) {
    if (
      correlations[i] >= Math.max(0.7, strongest * 0.89) &&
      correlations[i] >= correlations[i - 1] &&
      correlations[i] > correlations[i + 1]
    ) {
      const a = correlations[i - 1];
      const b = correlations[i];
      const c = correlations[i + 1];
      const offset = (a - c) / (2 * (a - 2 * b + c) || 1);
      return sampleRate / (minLag + i + Math.max(-0.5, Math.min(0.5, offset)));
    }
  }
  return null;
}

export function usePitchDetection(onNote: (noteId: string) => void) {
  const [isListening, setIsListening] = useState(false);
  const [detectedNote, setDetectedNote] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const resourcesRef = useRef<MicrophoneResources | null>(null);
  const onNoteRef = useRef(onNote);
  const stabilityRef = useRef({ note: "", count: 0, emitted: "", silentFrames: 0 });

  useEffect(() => {
    onNoteRef.current = onNote;
  }, [onNote]);

  const stop = useCallback(() => {
    const resources = resourcesRef.current;
    if (resources) {
      window.clearInterval(resources.timer);
      resources.source.disconnect();
      resources.stream.getTracks().forEach((track) => track.stop());
      void resources.context.close();
      resourcesRef.current = null;
    }
    stabilityRef.current = { note: "", count: 0, emitted: "", silentFrames: 0 };
    setIsListening(false);
    setDetectedNote(null);
  }, []);

  const start = useCallback(async () => {
    if (resourcesRef.current) return;
    setError(null);

    if (!navigator.mediaDevices?.getUserMedia) {
      setError("Dein Browser unterstützt leider kein Mikrofon. Du kannst die Bildschirmtasten benutzen.");
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false },
      });
      const context = new AudioContext();
      const source = context.createMediaStreamSource(stream);
      const analyser = context.createAnalyser();
      analyser.fftSize = 4096;
      source.connect(analyser);
      const buffer = new Float32Array(analyser.fftSize);

      const timer = window.setInterval(() => {
        analyser.getFloatTimeDomainData(buffer);
        const frequency = estimateFrequency(buffer, context.sampleRate);
        const stable = stabilityRef.current;

        if (!frequency) {
          stable.silentFrames++;
          if (stable.silentFrames >= 3) {
            stable.note = "";
            stable.count = 0;
            stable.emitted = "";
            setDetectedNote(null);
          }
          return;
        }

        stable.silentFrames = 0;
        const midi = Math.round(69 + 12 * Math.log2(frequency / 440));
        const noteId = `${NOTE_NAMES[((midi % 12) + 12) % 12]}${Math.floor(midi / 12) - 1}`;
        const exactFrequency = 440 * 2 ** ((midi - 69) / 12);

        if (!NOTE_BY_ID[noteId] || Math.abs(1200 * Math.log2(frequency / exactFrequency)) > 45) return;
        if (stable.note === noteId) stable.count++;
        else {
          stable.note = noteId;
          stable.count = 1;
        }
        if (stable.count >= 2) setDetectedNote(noteId);
        if (stable.count >= 2 && stable.emitted !== noteId) {
          stable.emitted = noteId;
          onNoteRef.current(noteId);
        }
      }, 95);

      resourcesRef.current = { stream, context, source, analyser, timer };
      setIsListening(true);
    } catch {
      setError("Mikrofon nicht verfügbar. Erlaube den Zugriff oder spiele mit den Bildschirmtasten.");
    }
  }, []);

  useEffect(() => () => stop(), [stop]);

  return { isListening, detectedNote, error, start, stop };
}
