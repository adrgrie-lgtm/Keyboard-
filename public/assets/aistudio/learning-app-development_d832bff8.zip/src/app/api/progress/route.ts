import { randomUUID } from "node:crypto";
import { cookies } from "next/headers";
import { NextResponse } from "next/server";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { learnerProgress, type LearnerProgress } from "@/db/schema";
import { LESSONS } from "@/lib/music-data";

export const dynamic = "force-dynamic";

const COOKIE_NAME = "klimper_visitor";

async function visitor() {
  const store = await cookies();
  const stored = store.get(COOKIE_NAME)?.value;
  const valid = stored && /^[0-9a-f-]{36}$/i.test(stored);
  return { id: valid ? stored : randomUUID(), isNew: !valid };
}

async function ensureProgress(id: string): Promise<LearnerProgress> {
  const [existing] = await db.select().from(learnerProgress).where(eq(learnerProgress.visitorId, id)).limit(1);
  if (existing) return existing;
  await db.insert(learnerProgress).values({ visitorId: id }).onConflictDoNothing();
  const [created] = await db.select().from(learnerProgress).where(eq(learnerProgress.visitorId, id)).limit(1);
  return created;
}

function publicProgress(row: LearnerProgress) {
  return {
    completedLessonIds: row.completedLessonIds,
    totalNotesPlayed: row.totalNotesPlayed,
    practiceSeconds: row.practiceSeconds,
    lastPracticedAt: row.lastPracticedAt?.toISOString() ?? null,
  };
}

function reply(data: object, id: string, isNew: boolean, status = 200) {
  const response = NextResponse.json(data, { status });
  response.headers.set("Cache-Control", "no-store");
  if (isNew) {
    response.cookies.set(COOKIE_NAME, id, {
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      path: "/",
      maxAge: 60 * 60 * 24 * 365,
    });
  }
  return response;
}

export async function GET() {
  const { id, isNew } = await visitor();
  try {
    const progress = await ensureProgress(id);
    return reply({ progress: publicProgress(progress) }, id, isNew);
  } catch {
    return reply({ error: "Der Lernfortschritt konnte nicht geladen werden." }, id, isNew, 500);
  }
}

export async function POST(request: Request) {
  const { id, isNew } = await visitor();
  let body: Record<string, unknown>;
  try {
    body = await request.json();
    if (!body || typeof body !== "object" || Array.isArray(body)) throw new Error("Invalid body");
  } catch {
    return reply({ error: "Ungültige Anfrage." }, id, isNew, 400);
  }

  try {
    const current = await ensureProgress(id);

    if (body.action === "practice") {
      const notes = body.notes;
      const seconds = body.seconds;
      if (
        typeof notes !== "number" || !Number.isInteger(notes) || notes < 0 || notes > 500 ||
        typeof seconds !== "number" || !Number.isInteger(seconds) || seconds < 0 || seconds > 3600
      ) {
        return reply({ error: "Ungültige Übungsdaten." }, id, isNew, 400);
      }
      if (notes === 0 && seconds === 0) return reply({ progress: publicProgress(current) }, id, isNew);

      const [updated] = await db.update(learnerProgress).set({
        totalNotesPlayed: sql`${learnerProgress.totalNotesPlayed} + ${notes}`,
        practiceSeconds: sql`${learnerProgress.practiceSeconds} + ${seconds}`,
        lastPracticedAt: new Date(),
        updatedAt: new Date(),
      }).where(eq(learnerProgress.visitorId, id)).returning();
      return reply({ progress: publicProgress(updated) }, id, isNew);
    }

    if (body.action === "complete") {
      const lessonId = body.lessonId;
      if (typeof lessonId !== "string" || !LESSONS.some((lesson) => lesson.id === lessonId)) {
        return reply({ error: "Unbekannte Lektion." }, id, isNew, 400);
      }
      const completedLessonIds = current.completedLessonIds.includes(lessonId)
        ? current.completedLessonIds
        : [...current.completedLessonIds, lessonId];
      const [updated] = await db.update(learnerProgress).set({
        completedLessonIds,
        updatedAt: new Date(),
      }).where(eq(learnerProgress.visitorId, id)).returning();
      return reply({ progress: publicProgress(updated) }, id, isNew);
    }

    return reply({ error: "Unbekannte Aktion." }, id, isNew, 400);
  } catch {
    return reply({ error: "Speichern ist gerade nicht möglich. Bitte versuche es erneut." }, id, isNew, 500);
  }
}
