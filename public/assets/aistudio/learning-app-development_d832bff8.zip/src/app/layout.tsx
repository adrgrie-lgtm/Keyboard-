import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "klimper. – Spielerisch Keyboard lernen",
  description: "Entdecke dein Keyboard mit interaktiven Lektionen, Kinderliedern und einer eigenen Klaviatur. Ein Ton nach dem anderen.",
  applicationName: "klimper.",
};

export const viewport: Viewport = {
  themeColor: "#faf9fb",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="de">
      <body>{children}</body>
    </html>
  );
}
