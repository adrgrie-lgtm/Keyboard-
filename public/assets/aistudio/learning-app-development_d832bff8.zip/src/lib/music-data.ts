export type PianoNote = {
  id: string;
  name: string;
  octave: number;
  display: string;
  number?: string;
  frequency: number;
  black?: boolean;
  afterWhite?: number;
  shortcut?: string;
};

export type Accent = "rose" | "violet" | "peach" | "mint" | "blue" | "yellow";

export type Lesson = {
  id: string;
  number: string;
  title: string;
  subtitle: string;
  description: string;
  duration: string;
  accent: Accent;
  icon: "keyboard" | "notes" | "arrows" | "song" | "sparkles" | "star";
  notes: string[];
  hint: string;
  fact: string;
  reward: string;
};

export type Song = {
  id: string;
  title: string;
  subtitle: string;
  notes: string[];
  accent: Accent;
};

export const WHITE_NOTES: PianoNote[] = [
  { id: "C4", name: "C", octave: 4, display: "C", number: "1", frequency: 261.63, shortcut: "A" },
  { id: "D4", name: "D", octave: 4, display: "D", number: "2", frequency: 293.66, shortcut: "S" },
  { id: "E4", name: "E", octave: 4, display: "E", number: "3", frequency: 329.63, shortcut: "D" },
  { id: "F4", name: "F", octave: 4, display: "F", number: "4", frequency: 349.23, shortcut: "F" },
  { id: "G4", name: "G", octave: 4, display: "G", number: "5", frequency: 392, shortcut: "G" },
  { id: "A4", name: "A", octave: 4, display: "A", number: "6", frequency: 440, shortcut: "H" },
  { id: "B4", name: "B", octave: 4, display: "B", number: "7", frequency: 493.88, shortcut: "J" },
  { id: "C5", name: "C", octave: 5, display: "C′", number: "1", frequency: 523.25, shortcut: "K" },
  { id: "D5", name: "D", octave: 5, display: "D′", number: "2", frequency: 587.33 },
  { id: "E5", name: "E", octave: 5, display: "E′", number: "3", frequency: 659.25 },
  { id: "F5", name: "F", octave: 5, display: "F′", number: "4", frequency: 698.46 },
  { id: "G5", name: "G", octave: 5, display: "G′", number: "5", frequency: 783.99 },
  { id: "A5", name: "A", octave: 5, display: "A′", number: "6", frequency: 880 },
  { id: "B5", name: "B", octave: 5, display: "B′", number: "7", frequency: 987.77 },
  { id: "C6", name: "C", octave: 6, display: "C″", number: "1", frequency: 1046.5 },
];

export const BLACK_NOTES: PianoNote[] = [
  { id: "C#4", name: "C♯", octave: 4, display: "C♯", frequency: 277.18, black: true, afterWhite: 0, shortcut: "W" },
  { id: "D#4", name: "D♯", octave: 4, display: "D♯", frequency: 311.13, black: true, afterWhite: 1, shortcut: "E" },
  { id: "F#4", name: "F♯", octave: 4, display: "F♯", frequency: 369.99, black: true, afterWhite: 3, shortcut: "T" },
  { id: "G#4", name: "G♯", octave: 4, display: "G♯", frequency: 415.3, black: true, afterWhite: 4, shortcut: "Z" },
  { id: "A#4", name: "A♯", octave: 4, display: "A♯", frequency: 466.16, black: true, afterWhite: 5, shortcut: "U" },
  { id: "C#5", name: "C♯", octave: 5, display: "C♯′", frequency: 554.37, black: true, afterWhite: 7 },
  { id: "D#5", name: "D♯", octave: 5, display: "D♯′", frequency: 622.25, black: true, afterWhite: 8 },
  { id: "F#5", name: "F♯", octave: 5, display: "F♯′", frequency: 739.99, black: true, afterWhite: 10 },
  { id: "G#5", name: "G♯", octave: 5, display: "G♯′", frequency: 830.61, black: true, afterWhite: 11 },
  { id: "A#5", name: "A♯", octave: 5, display: "A♯′", frequency: 932.33, black: true, afterWhite: 12 },
];

export const ALL_NOTES = [...WHITE_NOTES, ...BLACK_NOTES];
export const NOTE_BY_ID: Record<string, PianoNote> = Object.fromEntries(
  ALL_NOTES.map((note) => [note.id, note]),
);

export const LESSONS: Lesson[] = [
  {
    id: "erste-tasten",
    number: "01",
    title: "Die ersten Tasten",
    subtitle: "Lerne C, D und E kennen.",
    description: "Finde die ersten weißen Tasten auf deinem Keyboard und spiele eine kleine Tonfolge.",
    duration: "4 Min",
    accent: "rose",
    icon: "keyboard",
    notes: ["C4", "D4", "E4", "D4", "C4"],
    hint: "Das C liegt links neben einer Gruppe aus zwei schwarzen Tasten. Auf deinem Keyboard trägt es die Zahl 1.",
    fact: "Die weißen Tasten wiederholen sich immer in derselben Reihenfolge: C · D · E · F · G · A · B.",
    reward: "Tastenfinder",
  },
  {
    id: "fuenf-toene",
    number: "02",
    title: "Fünf Töne, ein Lied",
    subtitle: "Von C bis G und zurück.",
    description: "Spiele fünf Töne nacheinander. Hörst du schon eine kleine Melodie?",
    duration: "5 Min",
    accent: "violet",
    icon: "notes",
    notes: ["C4", "D4", "E4", "F4", "G4", "G4", "F4", "E4", "D4", "C4"],
    hint: "Gehe Taste für Taste nach rechts bis zum G. Danach spielst du den Weg wieder zurück.",
    fact: "Wenn die Töne nach rechts wandern, klingen sie höher. Nach links werden sie tiefer.",
    reward: "Tonleiter-Talent",
  },
  {
    id: "hoch-und-tief",
    number: "03",
    title: "Hoch & tief",
    subtitle: "Entdecke das nächste C.",
    description: "Springe über die Tasten und finde heraus, wie hoch und tief zusammen klingen.",
    duration: "5 Min",
    accent: "peach",
    icon: "arrows",
    notes: ["C4", "G4", "C5", "G4", "C4", "E4", "G4", "C5"],
    hint: "Das C′ ist das nächste C weiter rechts. Nach B beginnt die Reihe wieder bei C.",
    fact: "Vom ersten C bis zum nächsten C sind es acht weiße Tasten – das nennt man eine Oktave.",
    reward: "Oktaven-Entdecker",
  },
  {
    id: "alle-meine-entchen",
    number: "04",
    title: "Alle meine Entchen",
    subtitle: "Dein erstes bekanntes Lied.",
    description: "Eine Melodie zum Mitsummen: Spiele den Anfang von „Alle meine Entchen“.",
    duration: "6 Min",
    accent: "mint",
    icon: "song",
    notes: ["C4", "D4", "E4", "F4", "G4", "G4", "A4", "A4", "A4", "A4", "G4"],
    hint: "Beginne beim C und laufe bis zum G. Das G und später das A darfst du wiederholen.",
    fact: "Wiederholte Töne geben einer Melodie ihren Rhythmus. Lass dir Zeit für jeden einzelnen Ton.",
    reward: "Entchen-Dirigent",
  },
  {
    id: "bruder-jakob",
    number: "05",
    title: "Bruder Jakob",
    subtitle: "Eine Melodie mit Wiederholung.",
    description: "Spiele die ersten Zeilen des Liedes und entdecke ein musikalisches Muster.",
    duration: "6 Min",
    accent: "blue",
    icon: "sparkles",
    notes: ["C4", "D4", "E4", "C4", "C4", "D4", "E4", "C4", "E4", "F4", "G4"],
    hint: "Die ersten vier Töne heißen C – D – E – C. Danach spielst du dieselbe Folge noch einmal.",
    fact: "Viele Lieder bestehen aus kleinen Mustern, die mehrmals vorkommen. So lassen sie sich leichter merken.",
    reward: "Melodie-Macher",
  },
  {
    id: "mini-konzert",
    number: "06",
    title: "Dein Mini-Konzert",
    subtitle: "Jetzt spielst du ganz allein.",
    description: "Zeige, was du gelernt hast, mit einer fröhlichen Melodie aus verschiedenen Tönen.",
    duration: "7 Min",
    accent: "yellow",
    icon: "star",
    notes: ["G4", "E4", "E4", "F4", "D4", "D4", "C4", "D4", "E4", "F4", "G4", "G4", "G4"],
    hint: "Das ist der Anfang von „Hänschen klein“. Spiele langsam und achte auf die wiederholten Tasten.",
    fact: "Musik muss nicht perfekt sein. Das Schönste ist, wenn du Spaß am Spielen hast!",
    reward: "Konzertstar",
  },
];

export const SONGS: Song[] = [
  {
    id: "entchen",
    title: "Alle meine Entchen",
    subtitle: "Ein fröhlicher Klassiker",
    accent: "mint",
    notes: ["C4", "D4", "E4", "F4", "G4", "G4", "A4", "A4", "A4", "A4", "G4", "A4", "A4", "A4", "A4", "G4", "F4", "F4", "F4", "F4", "E4", "E4", "D4", "D4", "D4", "D4", "C4"],
  },
  {
    id: "jakob",
    title: "Bruder Jakob",
    subtitle: "Zum Mitsingen & Mitspielen",
    accent: "violet",
    notes: ["C4", "D4", "E4", "C4", "C4", "D4", "E4", "C4", "E4", "F4", "G4", "E4", "F4", "G4"],
  },
  {
    id: "haenschen",
    title: "Hänschen klein",
    subtitle: "Ein Lied für dein Konzert",
    accent: "peach",
    notes: ["G4", "E4", "E4", "F4", "D4", "D4", "C4", "D4", "E4", "F4", "G4", "G4", "G4"],
  },
];
