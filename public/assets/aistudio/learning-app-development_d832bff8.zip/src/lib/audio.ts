import { NOTE_BY_ID } from "./music-data";

export type Instrument = "piano" | "bell" | "synth";

let audioContext: AudioContext | null = null;

function getAudioContext() {
  if (typeof window === "undefined") return null;
  audioContext ??= new AudioContext();
  if (audioContext.state === "suspended") void audioContext.resume();
  return audioContext;
}

export function playNote(
  noteId: string,
  instrument: Instrument = "piano",
  volume = 0.6,
  duration = 0.9,
) {
  const note = NOTE_BY_ID[noteId];
  const context = getAudioContext();
  if (!context || !note || volume <= 0) return;

  const now = context.currentTime;
  const master = context.createGain();
  master.gain.value = Math.min(1, Math.max(0, volume)) * 0.36;
  master.connect(context.destination);

  const voices: { ratio: number; level: number; type: OscillatorType; decay: number }[] =
    instrument === "bell"
      ? [
          { ratio: 1, level: 0.85, type: "sine", decay: 1.45 },
          { ratio: 2.01, level: 0.28, type: "sine", decay: 0.95 },
          { ratio: 3.93, level: 0.11, type: "sine", decay: 0.55 },
        ]
      : instrument === "synth"
        ? [
            { ratio: 1, level: 0.65, type: "triangle", decay: 0.85 },
            { ratio: 2, level: 0.22, type: "sine", decay: 0.7 },
          ]
        : [
            { ratio: 1, level: 0.68, type: "triangle", decay: 1.05 },
            { ratio: 2, level: 0.24, type: "sine", decay: 0.72 },
            { ratio: 3, level: 0.1, type: "sine", decay: 0.48 },
          ];

  voices.forEach((voice) => {
    const oscillator = context.createOscillator();
    const envelope = context.createGain();
    const end = now + Math.max(0.22, duration * voice.decay);

    oscillator.type = voice.type;
    oscillator.frequency.setValueAtTime(note.frequency * voice.ratio, now);
    envelope.gain.setValueAtTime(0.0001, now);
    envelope.gain.exponentialRampToValueAtTime(Math.max(0.001, voice.level), now + 0.012);
    envelope.gain.exponentialRampToValueAtTime(0.0001, end);

    oscillator.connect(envelope);
    envelope.connect(master);
    oscillator.start(now);
    oscillator.stop(end + 0.02);
  });
}
