"use client";

import Image from "next/image";
import { useEffect, useRef, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  AudioLines,
  BookOpen,
  Check,
  CheckCircle2,
  ChevronRight,
  CircleHelp,
  Clock3,
  Headphones,
  House,
  Keyboard,
  Lightbulb,
  Mic,
  MicOff,
  Music2,
  Pause,
  Play,
  RotateCcw,
  Settings2,
  Sparkles,
  Star,
  Trophy,
  Volume2,
  VolumeX,
  WandSparkles,
  X,
  ChartNoAxesColumn,
} from "lucide-react";
import { PianoKeyboard } from "@/components/piano-keyboard";
import { usePitchDetection } from "@/hooks/use-pitch-detection";
import { playNote, type Instrument } from "@/lib/audio";
import { LESSONS, NOTE_BY_ID, SONGS, type Lesson, type Song } from "@/lib/music-data";

type View = "dashboard" | "lessons" | "lesson" | "play" | "progress" | "guide";
type PracticeMode = "screen" | "keyboard";
type Feedback = { kind: "good" | "try"; text: string } | null;
type Progress = {
  completedLessonIds: string[];
  totalNotesPlayed: number;
  practiceSeconds: number;
  lastPracticedAt: string | null;
};

const EMPTY_PROGRESS: Progress = {
  completedLessonIds: [],
  totalNotesPlayed: 0,
  practiceSeconds: 0,
  lastPracticedAt: null,
};

const NAV_ITEMS = [
  { id: "dashboard" as const, label: "Übersicht", icon: House },
  { id: "lessons" as const, label: "Lernpfad", icon: BookOpen },
  { id: "play" as const, label: "Freies Spielen", icon: Music2 },
  { id: "progress" as const, label: "Fortschritt", icon: ChartNoAxesColumn },
  { id: "guide" as const, label: "Mein Keyboard", icon: Keyboard },
];

const SHORTCUTS: Record<string, string> = {
  a: "C4", w: "C#4", s: "D4", e: "D#4", d: "E4", f: "F4",
  t: "F#4", g: "G4", z: "G#4", h: "A4", u: "A#4", j: "B4", k: "C5",
};

function LessonGlyph({ lesson, size = 23 }: { lesson: Lesson; size?: number }) {
  if (lesson.icon === "keyboard") return <Keyboard size={size} strokeWidth={1.9} />;
  if (lesson.icon === "notes") return <Music2 size={size} strokeWidth={1.9} />;
  if (lesson.icon === "arrows") return <AudioLines size={size} strokeWidth={1.9} />;
  if (lesson.icon === "song") return <BookOpen size={size} strokeWidth={1.9} />;
  if (lesson.icon === "sparkles") return <Sparkles size={size} strokeWidth={1.9} />;
  return <Star size={size} strokeWidth={1.9} />;
}

function ProgressRing({ percent, size = 126 }: { percent: number; size?: number }) {
  const radius = 49;
  const circumference = 2 * Math.PI * radius;
  return (
    <div className="progress-ring" style={{ width: size, height: size }}>
      <svg viewBox="0 0 120 120" aria-hidden="true">
        <circle className="ring-track" cx="60" cy="60" r={radius} strokeWidth="10" fill="none" />
        <circle
          className="ring-fill"
          cx="60"
          cy="60"
          r={radius}
          strokeWidth="10"
          fill="none"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={circumference * (1 - percent / 100)}
        />
      </svg>
      <div className="ring-value"><strong>{percent}%</strong><span>geschafft</span></div>
    </div>
  );
}

function ModeSwitch({ mode, onChange }: { mode: PracticeMode; onChange: (mode: PracticeMode) => void }) {
  return (
    <div className="mode-switch" role="group" aria-label="Spielweise auswählen">
      <button type="button" className={mode === "screen" ? "selected" : ""} onClick={() => onChange("screen")}>
        <Keyboard size={16} /> Bildschirm
      </button>
      <button type="button" className={mode === "keyboard" ? "selected" : ""} onClick={() => onChange("keyboard")}>
        <Music2 size={16} /> Mein Keyboard
      </button>
    </div>
  );
}

function MicrophonePanel({
  isListening,
  detectedNote,
  error,
  onToggle,
}: {
  isListening: boolean;
  detectedNote: string | null;
  error: string | null;
  onToggle: () => void;
}) {
  return (
    <div className={`microphone-panel ${isListening ? "microphone-panel-live" : ""}`}>
      <div className="microphone-icon">{isListening ? <AudioLines size={21} /> : <Mic size={21} />}</div>
      <div className="microphone-copy">
        <strong>{isListening ? "Ich höre zu!" : "Spiele auf deinem echten Keyboard"}</strong>
        <span>
          {isListening
            ? detectedNote ? `Erkannt: ${NOTE_BY_ID[detectedNote]?.display ?? detectedNote}` : "Spiele einen einzelnen Ton auf deinem Keyboard."
            : "Mit dem Mikrofon kann die App deine Töne erkennen. Oder tippe die Taste hier an."}
        </span>
      </div>
      <button type="button" className={`mic-button ${isListening ? "mic-button-on" : ""}`} onClick={onToggle}>
        {isListening ? <><MicOff size={16} /> Ausschalten</> : <><Mic size={16} /> Mikrofon an</>}
      </button>
      {error && <p className="mic-error">{error}</p>}
    </div>
  );
}

function formatPracticeTime(seconds: number) {
  if (seconds === 0) return "0 Min";
  if (seconds < 60) return "< 1 Min";
  return `${Math.floor(seconds / 60)} Min`;
}

export function MusicApp() {
  const [view, setView] = useState<View>("dashboard");
  const [progress, setProgress] = useState<Progress>(EMPTY_PROGRESS);
  const [progressError, setProgressError] = useState(false);
  const [activeLesson, setActiveLesson] = useState<Lesson | null>(null);
  const [lessonStep, setLessonStep] = useState(0);
  const [lessonFinished, setLessonFinished] = useState(false);
  const [feedback, setFeedback] = useState<Feedback>(null);
  const [practiceMode, setPracticeMode] = useState<PracticeMode>("screen");
  const [activeNote, setActiveNote] = useState<string | null>(null);
  const [instrument, setInstrument] = useState<Instrument>("piano");
  const [volume, setVolume] = useState(0.65);
  const [muted, setMuted] = useState(false);
  const [showNames, setShowNames] = useState(true);
  const [selectedSongId, setSelectedSongId] = useState(SONGS[0].id);
  const [guidedSongId, setGuidedSongId] = useState<string | null>(null);
  const [songStep, setSongStep] = useState(0);
  const [songFinished, setSongFinished] = useState(false);
  const [songFeedback, setSongFeedback] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [recordedNotes, setRecordedNotes] = useState<string[]>([]);
  const [sessionNotes, setSessionNotes] = useState(0);
  const [isDemoPlaying, setIsDemoPlaying] = useState(false);
  const [toast, setToast] = useState("");

  const pendingNotesRef = useRef(0);
  const pendingStartedAtRef = useRef<number | null>(null);
  const saveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const activeTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const toastTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const demoRunRef = useRef(0);

  useEffect(() => {
    fetch("/api/progress", { cache: "no-store" })
      .then((response) => {
        if (!response.ok) throw new Error("Could not load progress");
        return response.json();
      })
      .then((data: { progress: Progress }) => {
        setProgress({ ...data.progress, totalNotesPlayed: data.progress.totalNotesPlayed + pendingNotesRef.current });
      })
      .catch(() => setProgressError(true));
  }, []);

  async function flushPractice() {
    if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
    saveTimerRef.current = null;
    const notes = pendingNotesRef.current;
    if (notes === 0) return;
    const seconds = Math.max(1, Math.min(3600, Math.round((Date.now() - (pendingStartedAtRef.current ?? Date.now())) / 1000)));
    pendingNotesRef.current = 0;
    pendingStartedAtRef.current = null;
    try {
      const response = await fetch("/api/progress", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "practice", notes, seconds }),
      });
      if (!response.ok) throw new Error("Save failed");
      setProgressError(false);
      setProgress((previous) => ({ ...previous, practiceSeconds: previous.practiceSeconds + seconds, lastPracticedAt: new Date().toISOString() }));
    } catch {
      pendingNotesRef.current += notes;
      pendingStartedAtRef.current ??= Date.now();
      setProgressError(true);
    }
  }

  useEffect(() => {
    function saveOnLeave() {
      if (pendingNotesRef.current === 0) return;
      const notes = pendingNotesRef.current;
      const seconds = Math.max(1, Math.round((Date.now() - (pendingStartedAtRef.current ?? Date.now())) / 1000));
      pendingNotesRef.current = 0;
      navigator.sendBeacon?.("/api/progress", new Blob([JSON.stringify({ action: "practice", notes, seconds })], { type: "application/json" }));
    }
    window.addEventListener("pagehide", saveOnLeave);
    return () => window.removeEventListener("pagehide", saveOnLeave);
  }, []);

  function queuePracticeNote() {
    if (pendingNotesRef.current === 0) pendingStartedAtRef.current = Date.now();
    pendingNotesRef.current += 1;
    setProgress((previous) => ({ ...previous, totalNotesPlayed: previous.totalNotesPlayed + 1 }));
    if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
    saveTimerRef.current = setTimeout(() => void flushPractice(), 2200);
  }

  function showToast(message: string) {
    setToast(message);
    if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
    toastTimerRef.current = setTimeout(() => setToast(""), 3500);
  }

  function stopDemo() {
    demoRunRef.current += 1;
    setIsDemoPlaying(false);
    setActiveNote(null);
  }

  async function playDemo(notes: string[], speed = 470) {
    if (isDemoPlaying) stopDemo();
    const run = ++demoRunRef.current;
    setIsDemoPlaying(true);
    for (const noteId of notes) {
      if (demoRunRef.current !== run) return;
      setActiveNote(noteId);
      playNote(noteId, instrument, muted ? 0 : volume, Math.max(0.35, speed / 800));
      await new Promise((resolve) => setTimeout(resolve, speed));
    }
    if (demoRunRef.current === run) {
      setIsDemoPlaying(false);
      setActiveNote(null);
    }
  }

  async function saveLessonCompletion(lessonId: string) {
    setProgress((previous) => ({
      ...previous,
      completedLessonIds: [...new Set([...previous.completedLessonIds, lessonId])],
    }));
    await flushPractice();
    try {
      const response = await fetch("/api/progress", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "complete", lessonId }),
      });
      if (!response.ok) throw new Error("Save failed");
      setProgressError(false);
    } catch {
      setProgressError(true);
      showToast("Dein Erfolg konnte gerade nicht gespeichert werden. Versuche es später erneut.");
    }
  }

  function handlePlayedNote(noteId: string, source: "screen" | "mic" = "screen") {
    if (!NOTE_BY_ID[noteId]) return;
    if (source === "screen") playNote(noteId, instrument, muted ? 0 : volume);
    setActiveNote(noteId);
    if (activeTimerRef.current) clearTimeout(activeTimerRef.current);
    activeTimerRef.current = setTimeout(() => setActiveNote(null), 360);
    queuePracticeNote();

    if (view === "lesson" && activeLesson && !lessonFinished) {
      const expected = activeLesson.notes[lessonStep];
      if (noteId === expected) {
        if (lessonStep === activeLesson.notes.length - 1) {
          setLessonFinished(true);
          setFeedback({ kind: "good", text: "Geschafft! Du hast alle Töne richtig gespielt." });
          void saveLessonCompletion(activeLesson.id);
        } else {
          setLessonStep((step) => step + 1);
          setFeedback({ kind: "good", text: "Super! Genau der richtige Ton." });
        }
      } else {
        setFeedback({ kind: "try", text: `Fast! Als Nächstes ist ${NOTE_BY_ID[expected].display} dran.` });
      }
    }

    if (view === "play") {
      setSessionNotes((count) => count + 1);
      if (isRecording) setRecordedNotes((notes) => notes.length < 100 ? [...notes, noteId] : notes);
      const song = SONGS.find((item) => item.id === guidedSongId);
      if (song && !songFinished) {
        if (noteId === song.notes[songStep]) {
          if (songStep === song.notes.length - 1) {
            setSongFinished(true);
            setSongFeedback("Bravo! Du hast das ganze Lied gespielt. 🎉");
          } else {
            setSongStep((step) => step + 1);
            setSongFeedback("Richtig! Weiter so.");
          }
        } else {
          setSongFeedback(`Versuch es mit ${NOTE_BY_ID[song.notes[songStep]].display}.`);
        }
      }
    }
  }

  const microphone = usePitchDetection((noteId) => handlePlayedNote(noteId, "mic"));

  useEffect(() => {
    function onKeyDown(event: KeyboardEvent) {
      const target = event.target as HTMLElement;
      if (event.repeat || event.altKey || event.ctrlKey || event.metaKey || ["INPUT", "TEXTAREA", "SELECT"].includes(target.tagName)) return;
      if (!["dashboard", "lesson", "play"].includes(view)) return;
      const noteId = SHORTCUTS[event.key.toLowerCase()];
      if (noteId) {
        event.preventDefault();
        handlePlayedNote(noteId);
      }
    }
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  });

  function navigate(nextView: View) {
    stopDemo();
    if (nextView !== "lesson" && nextView !== "play") microphone.stop();
    void flushPractice();
    setView(nextView);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function startLesson(lesson: Lesson) {
    stopDemo();
    microphone.stop();
    setPracticeMode("screen");
    setActiveLesson(lesson);
    setLessonStep(0);
    setLessonFinished(false);
    setFeedback(null);
    setView("lesson");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function changeMode(mode: PracticeMode) {
    setPracticeMode(mode);
    if (mode === "screen") microphone.stop();
  }

  function startGuidedSong(song: Song) {
    setSelectedSongId(song.id);
    setGuidedSongId(song.id);
    setSongStep(0);
    setSongFinished(false);
    setSongFeedback("Spiele die leuchtende Taste, um zu beginnen.");
    document.getElementById("play-keyboard")?.scrollIntoView({ behavior: "smooth", block: "center" });
  }

  const completedCount = progress.completedLessonIds.length;
  const percent = Math.round((completedCount / LESSONS.length) * 100);
  const nextLesson = LESSONS.find((lesson) => !progress.completedLessonIds.includes(lesson.id)) ?? LESSONS[0];
  const selectedSong = SONGS.find((song) => song.id === selectedSongId) ?? SONGS[0];
  const guidedSong = SONGS.find((song) => song.id === guidedSongId);
  const activeNav = view === "lesson" ? "lessons" : view;
  const viewLabel = view === "lesson" ? activeLesson?.title ?? "Lektion" : NAV_ITEMS.find((item) => item.id === view)?.label ?? "Übersicht";
  const lessonTarget = activeLesson && !lessonFinished ? activeLesson.notes[lessonStep] : null;

  function renderDashboard() {
    return (
      <>
        <div className="page-intro dashboard-intro">
          <div>
            <div className="eyebrow"><span className="eyebrow-line" /> DEIN PLATZ FÜR MUSIK</div>
            <h1>Hallo, Musikstar! <span className="heading-sparkle">✳</span></h1>
            <p>Schön, dass du da bist. Dein Keyboard wartet schon auf dich.</p>
          </div>
          <button type="button" className="button-outline intro-action" onClick={() => navigate("play")}>Einfach losspielen <ArrowUpRight size={17} /></button>
        </div>

        <section className="hero-card">
          <Image src="/images/pink-keyboard-hero.png" alt="Illustration eines kleinen rosa Keyboards" fill priority sizes="(max-width: 800px) 100vw, 60vw" className="hero-image" />
          <div className="hero-wash" />
          <div className="hero-content">
            <div className="hero-pill"><Sparkles size={14} /> {completedCount === LESSONS.length ? "DU HAST ES GESCHAFFT" : "DEIN NÄCHSTER SCHRITT"}</div>
            <h2>{completedCount === LESSONS.length ? "Wow, was für eine musikalische Reise!" : "Jede Melodie beginnt mit einer Taste."}</h2>
            <p>{completedCount === LESSONS.length ? "Alle Lektionen sind geschafft. Jetzt gehört die Bühne dir – spiel deine Lieblingsmelodie!" : `Entdecke in „${nextLesson.title}“, wie viel Musik schon in deinem Keyboard steckt.`}</p>
            <div className="hero-bottom">
              <button type="button" className="button-dark" onClick={() => completedCount === LESSONS.length ? navigate("play") : startLesson(nextLesson)}>
                {completedCount === LESSONS.length ? "Frei spielen" : "Lektion starten"} <ArrowRight size={18} />
              </button>
              <span className="hero-meta"><Clock3 size={15} /> {completedCount === LESSONS.length ? "Deine Bühne" : `Lektion ${nextLesson.number} · ${nextLesson.duration}`}</span>
            </div>
          </div>
        </section>

        <div className="dashboard-grid">
          <div className="dashboard-primary">
            <div className="section-heading">
              <div><span className="section-kicker">KLEINE SCHRITTE, GROSSE TÖNE</span><h2>Dein Lernpfad</h2><p>Finde deinen Rhythmus – in deinem Tempo.</p></div>
              <button type="button" className="text-link" onClick={() => navigate("lessons")}>Alle Lektionen <ArrowRight size={17} /></button>
            </div>
            <div className="dashboard-lesson-grid">
              {LESSONS.slice(0, 3).map((lesson) => {
                const done = progress.completedLessonIds.includes(lesson.id);
                return (
                  <button type="button" className={`lesson-preview ${lesson.id === nextLesson.id && completedCount < LESSONS.length ? "lesson-preview-next" : ""}`} key={lesson.id} onClick={() => startLesson(lesson)}>
                    <div className="preview-top"><span className={`lesson-icon accent-${lesson.accent}`}><LessonGlyph lesson={lesson} /></span><span className="preview-number">{done ? <CheckCircle2 size={20} /> : lesson.number}</span></div>
                    <div className="preview-content"><span className="preview-label">LEKTION {lesson.number}</span><h3>{lesson.title}</h3><p>{lesson.subtitle}</p></div>
                    <div className="preview-footer"><span><Clock3 size={14} /> {lesson.duration}</span><span className="preview-arrow"><ArrowUpRight size={18} /></span></div>
                  </button>
                );
              })}
            </div>
          </div>

          <aside className="progress-card">
            <div className="progress-card-head"><span className="progress-card-icon"><Trophy size={19} /></span><span>DEIN FORTSCHRITT</span></div>
            <ProgressRing percent={percent} />
            <h3>{completedCount === 0 ? "Du bist startklar!" : completedCount === LESSONS.length ? "Alles geschafft!" : "Weiter so!"}</h3>
            <p>{completedCount} von {LESSONS.length} Lektionen gemeistert</p>
            <div className="small-progress-track"><span style={{ width: `${percent}%` }} /></div>
            <div className="progress-card-tip"><Sparkles size={17} /><span>Jeder Ton bringt dich ein Stück weiter.</span></div>
          </aside>
        </div>

        <section className="quick-play-card">
          <div className="quick-play-copy"><span className="section-kicker">KLEINE MUSIKPAUSE?</span><h2>Einfach mal<br />drauflosspielen.</h2><p>Probier die Tasten aus – hier oder auf deinem Keyboard.</p><button type="button" className="text-link" onClick={() => navigate("play")}>Zum freien Spielen <ArrowRight size={17} /></button></div>
          <div className="quick-play-piano"><PianoKeyboard onPress={handlePlayedNote} activeNote={activeNote} whiteCount={8} compact showShortcuts /></div>
        </section>
      </>
    );
  }

  function renderLessons() {
    return (
      <>
        <div className="page-intro"><div><div className="eyebrow"><span className="eyebrow-line" /> DEIN LERNPFAD</div><h1>Ein Ton nach dem anderen.</h1><p>Sechs kleine Lektionen bringen dich zu deinem ersten Konzert.</p></div></div>
        <div className="path-banner"><div className="path-banner-icon"><WandSparkles size={25} /></div><div className="path-banner-copy"><strong>Deine musikalische Reise</strong><span>Du hast {completedCount} von {LESSONS.length} Lektionen geschafft. Mach in deinem Tempo weiter!</span></div><div className="path-banner-progress"><strong>{completedCount} / {LESSONS.length}</strong><div className="small-progress-track"><span style={{ width: `${percent}%` }} /></div></div></div>
        <div className="lesson-page-heading"><h2>Alle Lektionen</h2><span>Tippe eine Lektion an, um loszulegen</span></div>
        <div className="all-lessons-grid">
          {LESSONS.map((lesson) => {
            const done = progress.completedLessonIds.includes(lesson.id);
            const isNext = lesson.id === nextLesson.id && completedCount < LESSONS.length;
            return (
              <button type="button" key={lesson.id} className={`full-lesson-card ${isNext ? "full-lesson-next" : ""}`} onClick={() => startLesson(lesson)}>
                <div className="full-lesson-top"><span className={`lesson-icon lesson-icon-large accent-${lesson.accent}`}><LessonGlyph lesson={lesson} size={27} /></span><span className={`lesson-state ${done ? "lesson-state-done" : isNext ? "lesson-state-next" : ""}`}>{done ? <><Check size={13} /> GESCHAFFT</> : isNext ? "ALS NÄCHSTES" : `LEKTION ${lesson.number}`}</span></div>
                <span className="full-lesson-number">{lesson.number} / 06</span><h3>{lesson.title}</h3><p>{lesson.description}</p>
                <div className="full-lesson-footer"><span><Clock3 size={15} /> {lesson.duration}</span><span>{done ? "Nochmal spielen" : "Lektion öffnen"} <ArrowRight size={17} /></span></div>
              </button>
            );
          })}
        </div>
      </>
    );
  }

  function renderLesson() {
    if (!activeLesson) return null;
    const lessonIndex = LESSONS.findIndex((lesson) => lesson.id === activeLesson.id);
    const next = LESSONS[lessonIndex + 1];
    const target = lessonTarget ? NOTE_BY_ID[lessonTarget] : null;
    return (
      <>
        <button type="button" className="back-link" onClick={() => navigate("lessons")}><ArrowLeft size={17} /> Zurück zum Lernpfad</button>
        <div className="page-intro lesson-intro"><div><div className="eyebrow"><span className="eyebrow-line" /> LEKTION {activeLesson.number} VON 06</div><h1>{activeLesson.title}</h1><p>{activeLesson.description}</p></div><span className={`lesson-icon lesson-icon-large accent-${activeLesson.accent}`}><LessonGlyph lesson={activeLesson} size={28} /></span></div>
        <div className="lesson-layout">
          <section className="lesson-workspace">
            {lessonFinished ? (
              <div className="lesson-celebration">
                <div className="celebration-confetti" aria-hidden="true">✦ &nbsp; ♪ &nbsp; ✳</div>
                <div className="celebration-icon"><Trophy size={38} /></div>
                <span className="section-kicker">LEKTION GESCHAFFT</span>
                <h2>Das klang richtig gut!</h2>
                <p>Du hast alle {activeLesson.notes.length} Töne gespielt und dir den Titel <strong>„{activeLesson.reward}“</strong> verdient.</p>
                <div className="celebration-actions">
                  {next ? <button type="button" className="button-primary" onClick={() => startLesson(next)}>Nächste Lektion <ArrowRight size={17} /></button> : <button type="button" className="button-primary" onClick={() => navigate("play")}>Jetzt frei spielen <ArrowRight size={17} /></button>}
                  <button type="button" className="button-outline" onClick={() => navigate("lessons")}>Zum Lernpfad</button>
                </div>
              </div>
            ) : (
              <>
                <div className="workspace-top"><div><span className="section-kicker">JETZT BIST DU DRAN</span><h2>Spiele die Melodie mit.</h2></div><span className="step-counter">{lessonStep + 1} <span>/ {activeLesson.notes.length}</span></span></div>
                <div className="lesson-step-track" aria-label={`${lessonStep} von ${activeLesson.notes.length} Tönen gespielt`}>{activeLesson.notes.map((_, index) => <span key={index} className={`${index < lessonStep ? "complete" : ""} ${index === lessonStep ? "current" : ""}`} />)}</div>
                <div className="target-note-card"><div className="target-note-bubble">{target?.display}</div><div className="target-note-copy"><span>DEIN NÄCHSTER TON</span><h3>Spiele das {target?.display}</h3><p>Finde die leuchtende Taste auf dem Bildschirm oder auf deinem Keyboard.</p></div><button type="button" className="listen-button" onClick={() => target && playDemo([target.id], 550)} aria-label="Ton anhören"><Volume2 size={20} /></button></div>
                <div className="note-sequence-label">DIE TONFOLGE</div>
                <div className="note-sequence" aria-label="Tonfolge der Lektion">{activeLesson.notes.map((noteId, index) => <span key={`${noteId}-${index}`} className={`${index < lessonStep ? "played" : ""} ${index === lessonStep ? "now" : ""}`}>{NOTE_BY_ID[noteId].display}</span>)}</div>
                {feedback && <div className={`lesson-feedback feedback-${feedback.kind}`} role="status">{feedback.kind === "good" ? <CheckCircle2 size={17} /> : <Lightbulb size={17} />}{feedback.text}</div>}
                <div className="keyboard-area-head"><div><h3>Deine Tasten</h3><p>Tippe eine Taste an oder spiele auf deinem echten Keyboard.</p></div><ModeSwitch mode={practiceMode} onChange={changeMode} /></div>
                {practiceMode === "keyboard" && <MicrophonePanel isListening={microphone.isListening} detectedNote={microphone.detectedNote} error={microphone.error} onToggle={() => microphone.isListening ? microphone.stop() : void microphone.start()} />}
                <PianoKeyboard onPress={handlePlayedNote} activeNote={activeNote} targetNote={lessonTarget} whiteCount={8} showShortcuts />
                <div className="keyboard-caption"><span><span className="caption-dot" /> Die rosa Taste zeigt dir den nächsten Ton.</span><span>Computer-Tastatur: A S D F G H J K</span></div>
              </>
            )}
          </section>
          <aside className="lesson-side">
            <div className="tip-card"><div className="side-icon"><Lightbulb size={20} /></div><span className="section-kicker">KLEINER TIPP</span><h3>So findest du den Ton</h3><p>{activeLesson.hint}</p><button type="button" className="tip-listen" onClick={() => playDemo(activeLesson.notes.slice(0, Math.min(8, activeLesson.notes.length)), 530)}>{isDemoPlaying ? <Pause size={17} /> : <Play size={17} />} {isDemoPlaying ? "Nochmal starten" : "Melodie anhören"}</button></div>
            <div className="did-you-know"><span className="did-icon">♪</span><h3>Schon gewusst?</h3><p>{activeLesson.fact}</p></div>
          </aside>
        </div>
      </>
    );
  }

  function renderPlay() {
    return (
      <>
        <div className="page-intro play-intro"><div><div className="eyebrow"><span className="eyebrow-line" /> DEIN KLEINES MUSIKSTUDIO</div><h1>Spiel, was dein Herz hört. <span className="heading-sparkle">♪</span></h1><p>Hier darfst du ausprobieren, üben und einfach Spaß haben.</p></div><span className="play-intro-art"><Music2 size={34} /></span></div>
        <section className="play-studio" id="play-keyboard">
          <div className="studio-top"><div><span className="studio-live-dot" /> <span className="section-kicker">FREIES SPIELEN</span><h2>Dein Keyboard</h2></div><ModeSwitch mode={practiceMode} onChange={changeMode} /></div>
          <div className="studio-toolbar"><div className="instrument-tabs" role="group" aria-label="Klang auswählen"><span>KLANG</span>{(["piano", "bell", "synth"] as Instrument[]).map((sound) => <button key={sound} type="button" className={instrument === sound ? "selected" : ""} onClick={() => setInstrument(sound)}>{sound === "piano" ? "Klavier" : sound === "bell" ? "Glocken" : "Synth"}</button>)}</div><div className="studio-tools"><label className="volume-control"><Volume2 size={17} /><input type="range" min="0" max="1" step="0.05" value={volume} onChange={(event) => setVolume(Number(event.target.value))} aria-label="Lautstärke" /></label><button type="button" className={`names-toggle ${showNames ? "on" : ""}`} onClick={() => setShowNames(!showNames)} aria-pressed={showNames}>C D E <span className="toggle-knob" /></button></div></div>
          {practiceMode === "keyboard" && <MicrophonePanel isListening={microphone.isListening} detectedNote={microphone.detectedNote} error={microphone.error} onToggle={() => microphone.isListening ? microphone.stop() : void microphone.start()} />}
          {guidedSong && <div className={`guided-banner ${songFinished ? "guided-banner-done" : ""}`}><div><span className="section-kicker">SPIEL MIT · {guidedSong.title.toUpperCase()}</span><strong>{songFinished ? "Wunderbar gespielt!" : `Als Nächstes: ${NOTE_BY_ID[guidedSong.notes[songStep]].display}`}</strong><small>{songFeedback}</small></div><div className="guided-actions"><span>{Math.min(songStep + (songFinished ? 1 : 0), guidedSong.notes.length)} / {guidedSong.notes.length}</span><button type="button" onClick={() => { setGuidedSongId(null); setSongFinished(false); setSongFeedback(""); }} aria-label="Mitspielen beenden"><X size={17} /></button></div></div>}
          <PianoKeyboard onPress={handlePlayedNote} activeNote={activeNote} targetNote={guidedSong && !songFinished ? guidedSong.notes[songStep] : null} whiteCount={15} showNames={showNames} showShortcuts />
          <div className="studio-foot"><span><Keyboard size={16} /> Du kannst auch A S D F G H J K auf deiner Computertastatur drücken.</span><span>{sessionNotes} Töne in dieser Session gespielt</span></div>
        </section>
        <div className="play-below-grid">
          <section className="song-library"><div className="block-heading"><div><span className="section-kicker">MELODIEN ZUM AUSPROBIEREN</span><h2>Spiel ein Lied mit</h2><p>Hör erst zu und spiele dann selbst.</p></div><div className="block-heading-icon"><Music2 size={22} /></div></div><div className="song-list">{SONGS.map((song, index) => <div key={song.id} className={`song-row ${selectedSongId === song.id ? "song-row-selected" : ""}`}><button type="button" className="song-select" onClick={() => setSelectedSongId(song.id)}><span className={`song-symbol accent-${song.accent}`}>{index === 0 ? "♫" : index === 1 ? "♪" : "♬"}</span><span><strong>{song.title}</strong><small>{song.subtitle} · {song.notes.length} Töne</small></span></button><button type="button" className="song-play" onClick={() => { setSelectedSongId(song.id); void playDemo(song.notes, 385); }} title={`${song.title} anhören`} aria-label={`${song.title} anhören`}><Play size={17} fill="currentColor" /></button></div>)}</div><div className="song-library-footer"><span>Ausgewählt: <strong>{selectedSong.title}</strong></span><button type="button" className="button-primary button-primary-small" onClick={() => startGuidedSong(selectedSong)}>Mitspielen <ArrowRight size={16} /></button></div></section>
          <section className="record-card"><div className="block-heading"><div><span className="section-kicker">DEIN EIGENER SOUND</span><h2>Halte deine Idee fest</h2><p>Nimm eine kleine Melodie auf und hör sie dir an.</p></div><div className="record-icon"><AudioLines size={22} /></div></div><div className="record-visual"><span className={isRecording ? "record-light recording" : "record-light"} /><span>{isRecording ? "Aufnahme läuft ..." : recordedNotes.length ? `${recordedNotes.length} Töne aufgenommen` : "Bereit für deine Melodie"}</span><div className="record-bars" aria-hidden="true"><i /><i /><i /><i /><i /><i /><i /><i /><i /></div></div><div className="record-actions">{isRecording ? <button type="button" className="button-primary" onClick={() => { setIsRecording(false); showToast("Deine Melodie ist aufgenommen!"); }}><span className="stop-square" /> Aufnahme stoppen</button> : <button type="button" className="button-primary" onClick={() => { setRecordedNotes([]); setIsRecording(true); }}><span className="record-dot" /> Aufnahme starten</button>}<button type="button" className="button-outline icon-text-button" disabled={recordedNotes.length === 0 || isRecording} onClick={() => void playDemo(recordedNotes, 350)}><Play size={16} /> Anhören</button></div><p className="record-note">Die Aufnahme bleibt bis zum Neuladen dieser Seite erhalten.</p></section>
        </div>
      </>
    );
  }

  function renderProgress() {
    const achievements = [
      { name: "Erster Ton", description: "Spiele deinen ersten Ton", unlocked: progress.totalNotesPlayed > 0, icon: Music2, accent: "rose" },
      { name: "Tastenfinder", description: "Schaffe die erste Lektion", unlocked: completedCount >= 1, icon: Keyboard, accent: "violet" },
      { name: "Melodie-Macher", description: "Meistere drei Lektionen", unlocked: completedCount >= 3, icon: Sparkles, accent: "mint" },
      { name: "Konzertstar", description: "Schaffe alle sechs Lektionen", unlocked: completedCount >= LESSONS.length, icon: Trophy, accent: "yellow" },
    ];
    return (
      <>
        <div className="page-intro"><div><div className="eyebrow"><span className="eyebrow-line" /> DEINE MUSIKALISCHE REISE</div><h1>Schau, was du schon kannst.</h1><p>Jeder gespielte Ton ist ein kleiner Erfolg. Sei stolz auf dich!</p></div></div>
        {progressError && <div className="save-warning">Dein Fortschritt konnte gerade nicht synchronisiert werden. Wir versuchen es beim nächsten Ton erneut.</div>}
        <div className="stats-grid"><div className="stat-card"><span className="stat-icon accent-rose"><BookOpen size={24} /></span><span className="stat-label">LEKTIONEN GESCHAFFT</span><strong>{completedCount}<small> / {LESSONS.length}</small></strong><p>Schritt für Schritt ans Ziel</p></div><div className="stat-card"><span className="stat-icon accent-violet"><Music2 size={24} /></span><span className="stat-label">TÖNE GESPIELT</span><strong>{progress.totalNotesPlayed.toLocaleString("de-DE")}</strong><p>Jeder einzelne zählt</p></div><div className="stat-card"><span className="stat-icon accent-mint"><Clock3 size={24} /></span><span className="stat-label">ZEIT MIT MUSIK</span><strong className="time-stat">{formatPracticeTime(progress.practiceSeconds)}</strong><p>In deinem eigenen Tempo</p></div></div>
        <div className="progress-detail-grid"><section className="journey-card"><div className="block-heading"><div><span className="section-kicker">DEIN WEG</span><h2>Deine Lektionen</h2></div><ProgressRing percent={percent} size={92} /></div><div className="journey-list">{LESSONS.map((lesson) => { const done = progress.completedLessonIds.includes(lesson.id); return <button type="button" key={lesson.id} className="journey-row" onClick={() => startLesson(lesson)}><span className={`journey-marker ${done ? "done" : ""}`}>{done ? <Check size={16} /> : lesson.number}</span><span><strong>{lesson.title}</strong><small>{done ? "Gemeistert · Nochmal spielen" : lesson.subtitle}</small></span><ChevronRight size={18} /></button>; })}</div></section><section className="achievement-card"><div className="block-heading"><div><span className="section-kicker">SAMMLE MUSIKMOMENTE</span><h2>Deine Abzeichen</h2><p>Das hast du dir erspielt.</p></div><Trophy size={23} /></div><div className="achievement-list">{achievements.map((badge) => <div key={badge.name} className={`achievement-row ${!badge.unlocked ? "achievement-locked" : ""}`}><span className={`achievement-icon accent-${badge.accent}`}><badge.icon size={22} /></span><span><strong>{badge.name}</strong><small>{badge.description}</small></span>{badge.unlocked && <CheckCircle2 size={19} className="achievement-check" />}</div>)}</div><div className="achievement-message"><Star size={17} /><span>{completedCount === 0 ? "Dein erstes Abzeichen wartet schon auf dich!" : "Toll gemacht – mach weiter so!"}</span></div></section></div>
      </>
    );
  }

  function renderGuide() {
    return (
      <>
        <div className="page-intro"><div><div className="eyebrow"><span className="eyebrow-line" /> DEIN INSTRUMENT</div><h1>Lern dein Keyboard kennen.</h1><p>Alles, was du für die ersten Töne auf deinem rosa Keyboard wissen musst.</p></div></div>
        <section className="guide-hero"><div className="guide-hero-copy"><span className="hero-pill"><Sparkles size={14} /> DEIN MUSIKBEGLEITER</span><h2>Hallo, kleines Keyboard!</h2><p>Die weißen Tasten auf deinem Keyboard tragen Buchstaben und Zahlen. Genau diese Töne üben wir zusammen – ganz ohne Kabel oder Anmeldung.</p><button type="button" className="button-dark" onClick={() => startLesson(LESSONS[0])}>Erste Lektion starten <ArrowRight size={17} /></button></div><div className="guide-hero-picture"><Image src="/images/pink-keyboard-hero.png" alt="Rosa Keyboard als Lerninstrument" fill sizes="(max-width: 700px) 100vw, 45vw" /></div></section>
        <div className="guide-section-title"><span className="section-kicker">SO EINFACH GEHT’S</span><h2>In drei Schritten zum ersten Ton</h2></div>
        <div className="guide-steps"><div className="guide-step"><span className="guide-step-num">01</span><span className="guide-step-icon accent-rose"><Settings2 size={23} /></span><h3>Keyboard einschalten</h3><p>Schiebe den <strong>POWER</strong>-Schalter auf ON. Stelle die Lautstärke am Anfang lieber leise ein.</p></div><div className="guide-step"><span className="guide-step-num">02</span><span className="guide-step-icon accent-violet"><Keyboard size={23} /></span><h3>Das C finden</h3><p>Suche zwei schwarze Tasten nebeneinander. Die weiße Taste direkt links davon ist das <strong>C</strong>.</p></div><div className="guide-step"><span className="guide-step-num">03</span><span className="guide-step-icon accent-mint"><Music2 size={23} /></span><h3>Einfach spielen</h3><p>Drücke C, D und E nacheinander. Oder starte eine Lektion und lass dich von der App begleiten.</p></div></div>
        <section className="key-map-section"><div className="key-map-head"><div><span className="section-kicker">DEINE TASTEN AUF EINEN BLICK</span><h2>Ein Buchstabe. Eine Zahl. Ein Ton.</h2><p>Auf deinem Keyboard stehen die Notennamen direkt auf den weißen Tasten.</p></div><span className="map-decoration">♪</span></div><div className="key-map-grid">{["C", "D", "E", "F", "G", "A", "B"].map((name, index) => <button type="button" key={name} className="map-key" onClick={() => playNote(`${name}4`, instrument, muted ? 0 : volume)} aria-label={`Ton ${name} abspielen`}><span>{index + 1}</span><strong>{name}</strong><small>Tippen & hören</small></button>)}</div><div className="key-map-note"><Lightbulb size={18} /><p><strong>Gut zu wissen:</strong> Auf deinem Keyboard steht <strong>B</strong> für den siebten Ton. In vielen deutschen Notenbüchern heißt derselbe Ton <strong>H</strong>. Hier verwenden wir die Beschriftung deines Keyboards.</p></div></section>
        <div className="guide-bottom-grid"><div className="guide-info-card"><div className="side-icon"><Headphones size={22} /></div><h3>Die Tasten am Gerät</h3><p><strong>TONE</strong> ändert den Klang, <strong>VOLUME</strong> die Lautstärke und <strong>DEMO</strong> spielt eine Beispielmelodie ab. Für unsere Übungen reicht zunächst ein Klavierklang.</p></div><div className="guide-info-card guide-info-lilac"><div className="side-icon"><Mic size={22} /></div><h3>Mit dem echten Keyboard üben</h3><p>Wähle in einer Lektion „Mein Keyboard“ und aktiviere auf Wunsch das Mikrofon. Die App versucht dann, deine gespielten Töne zu erkennen. Du kannst die angezeigten Tasten auch einfach antippen.</p></div></div>
      </>
    );
  }

  return (
    <div className="app-layout">
      <aside className="sidebar">
        <button type="button" className="brand" onClick={() => navigate("dashboard")} aria-label="klimper Startseite"><span className="brand-mark"><Music2 size={23} strokeWidth={2.5} /></span><span className="brand-name">klimper<span>.</span><small>DEIN MUSIKSTUDIO</small></span></button>
        <div className="sidebar-nav-label">ENTDECKEN</div>
        <nav className="sidebar-nav" aria-label="Hauptnavigation">{NAV_ITEMS.map((item) => <button type="button" key={item.id} className={`nav-item ${activeNav === item.id ? "active" : ""}`} onClick={() => navigate(item.id)}><item.icon size={19} strokeWidth={activeNav === item.id ? 2.25 : 1.9} /><span>{item.label}</span>{activeNav === item.id && <span className="nav-active-dot" />}</button>)}</nav>
        <div className="sidebar-spacer" />
        <div className="sidebar-encouragement"><span className="encouragement-icon"><Sparkles size={20} /></span><strong>Musik ist für alle da.</strong><p>Du musst nicht perfekt sein. Hab einfach Freude an jedem Ton!</p><span className="encouragement-notes">♫ &nbsp; ♪</span></div>
        <button type="button" className="sidebar-profile" onClick={() => navigate("progress")}><span className="profile-avatar">♪</span><span><strong>Mein Lernprofil</strong><small>Deine musikalische Reise</small></span><ChevronRight size={16} /></button>
      </aside>

      <div className="main-column">
        <header className="topbar"><button type="button" className="mobile-brand" onClick={() => navigate("dashboard")}><span className="brand-mark"><Music2 size={19} /></span><strong>klimper<span>.</span></strong></button><div className="breadcrumbs"><span>Mein Musikstudio</span><ChevronRight size={14} /><strong>{viewLabel}</strong></div><div className="topbar-actions"><span className="ready-pill"><i /> Bereit für Musik</span><button type="button" className="top-icon-button" onClick={() => setMuted(!muted)} aria-label={muted ? "Ton einschalten" : "Ton ausschalten"} title={muted ? "Ton einschalten" : "Ton ausschalten"}>{muted ? <VolumeX size={19} /> : <Volume2 size={19} />}</button><button type="button" className="top-avatar" onClick={() => navigate("progress")} aria-label="Fortschritt öffnen">♪</button></div></header>
        <main className="content-wrap">{view === "dashboard" && renderDashboard()}{view === "lessons" && renderLessons()}{view === "lesson" && renderLesson()}{view === "play" && renderPlay()}{view === "progress" && renderProgress()}{view === "guide" && renderGuide()}<footer className="app-footer"><span>Mit Freude gemacht für kleine große Musikmomente. ♡</span><span>klimper. · Dein Musikstudio</span></footer></main>
      </div>

      <nav className="mobile-nav" aria-label="Mobile Navigation">{NAV_ITEMS.map((item) => <button type="button" key={item.id} className={activeNav === item.id ? "active" : ""} onClick={() => navigate(item.id)}><item.icon size={20} /><span>{item.id === "dashboard" ? "Start" : item.id === "lessons" ? "Lernen" : item.id === "play" ? "Spielen" : item.id === "progress" ? "Erfolge" : "Keyboard"}</span></button>)}</nav>
      {toast && <div className="toast-message" role="status"><CheckCircle2 size={18} />{toast}<button type="button" onClick={() => setToast("")} aria-label="Meldung schließen"><X size={16} /></button></div>}
    </div>
  );
}
