"use client";

import type { CSSProperties } from "react";
import { BLACK_NOTES, WHITE_NOTES } from "@/lib/music-data";

export type PianoKeyboardProps = {
  onPress: (noteId: string) => void;
  activeNote?: string | null;
  targetNote?: string | null;
  whiteCount?: 8 | 15;
  showNames?: boolean;
  showNumbers?: boolean;
  showShortcuts?: boolean;
  compact?: boolean;
};

export function PianoKeyboard({
  onPress,
  activeNote,
  targetNote,
  whiteCount = 8,
  showNames = true,
  showNumbers = true,
  showShortcuts = false,
  compact = false,
}: PianoKeyboardProps) {
  const whiteNotes = WHITE_NOTES.slice(0, whiteCount);
  const blackNotes = BLACK_NOTES.filter((note) => (note.afterWhite ?? 99) < whiteCount - 1);

  return (
    <div className={`piano-shell ${compact ? "piano-shell-compact" : ""}`}>
      <div className="piano-console" aria-hidden="true">
        <div className="piano-speaker"><span /><span /><span /><span /><span /></div>
        <div className="piano-console-center">
          <div className="piano-lcd"><span>♪</span> LET&apos;S PLAY</div>
          <div className="piano-console-controls"><i /><i /><i /></div>
        </div>
        <div className="piano-speaker"><span /><span /><span /><span /><span /></div>
      </div>
      <div className="keyboard-scroll">
        <div className={`piano-keys ${whiteCount === 15 ? "piano-keys-wide" : ""}`}>
          <div className="white-key-row">
            {whiteNotes.map((note) => (
              <button
                key={note.id}
                type="button"
                className={`white-key ${activeNote === note.id ? "is-playing" : ""} ${targetNote === note.id ? "is-target" : ""}`}
                onClick={() => onPress(note.id)}
                aria-label={`Taste ${note.display}${note.number ? `, Nummer ${note.number}` : ""}`}
              >
                {showNumbers && <span className="key-number">{note.number}</span>}
                <span className="key-bottom">
                  {showNames && <span className="key-name">{note.display}</span>}
                  {showShortcuts && note.shortcut && <span className="key-shortcut">{note.shortcut}</span>}
                </span>
              </button>
            ))}
          </div>
          {blackNotes.map((note) => (
            <button
              key={note.id}
              type="button"
              className={`black-key ${activeNote === note.id ? "is-playing" : ""} ${targetNote === note.id ? "is-target" : ""}`}
              style={{ left: `${(((note.afterWhite ?? 0) + 1) / whiteCount) * 100}%` } as CSSProperties}
              onClick={() => onPress(note.id)}
              aria-label={`Schwarze Taste ${note.display}`}
              title={note.display}
            >
              {showShortcuts && note.shortcut && <span>{note.shortcut}</span>}
            </button>
          ))}
        </div>
      </div>
      <div className="piano-front-edge" aria-hidden="true" />
    </div>
  );
}
