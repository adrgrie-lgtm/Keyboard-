import { integer, jsonb, pgTable, text, timestamp } from "drizzle-orm/pg-core";

export const learnerProgress = pgTable("learner_progress", {
  visitorId: text("visitor_id").primaryKey(),
  completedLessonIds: jsonb("completed_lesson_ids").$type<string[]>().notNull().default([]),
  totalNotesPlayed: integer("total_notes_played").notNull().default(0),
  practiceSeconds: integer("practice_seconds").notNull().default(0),
  lastPracticedAt: timestamp("last_practiced_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export type LearnerProgress = typeof learnerProgress.$inferSelect;
